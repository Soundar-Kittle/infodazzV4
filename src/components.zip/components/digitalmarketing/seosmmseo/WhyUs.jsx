import React from 'react'

export default function WhyUs() {
  return (
    <div>WhyUs</div>
  )
}
