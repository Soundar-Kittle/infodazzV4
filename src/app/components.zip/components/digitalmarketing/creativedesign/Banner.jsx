import React from 'react'

export default function Banner() {
  return (
    <div>Banner</div>
  )
}
