"use client";

import { useState } from "react";
import Link from "next/link";
import NavMenu from "./nav-menu";
import Image from "next/image";
import Logo from "../../../public/logo/logo_blue.png";
import Sidebar from "./Sidebar";

const Header = () => {
  const [isActive, setIsActive] = useState(false);

  return (
    <>
    <header className="sticky top-0 bg-white shadow-md z-50 h-24 flex items-center">
  <div className="container relative px-4 mx-auto">
    <div className="flex items-center justify-between py-4">
      {/* Logo */}
      <Link href="/" className="flex items-center z-20">
        <Image
          src={Logo}
          alt="Infodazz Logo"
          width={250}
          height={90}
          className="px-3"
        />
      </Link>

      {/* Mobile Button */}
      <button
        onClick={() => setIsActive(!isActive)}
        aria-label="Toggle Mobile Menu"
        className="xl:hidden w-10 h-10 bg-[#fef76f] rounded-full shadow-md flex flex-col items-start justify-center pl-3 group z-20"
      >
        <span className="w-3 group-hover:w-5 h-[3px] bg-black mb-[3px] transition-all duration-300"></span>
        <span className="w-5 group-hover:w-3 h-[2px] bg-black transition-all duration-300"></span>
      </button>
    </div>

    {/* Centered Desktop Nav */}
    <nav className="hidden xl:flex absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 space-x-10 px-6 z-10">
  <NavMenu />
</nav>
  </div>
</header>

      {/* Mobile Sidebar */}
      {isActive && (
        <div className="fixed inset-0 bg-black/30 z-40 xl:hidden">
          <div className="absolute top-0 right-0 w-72 h-full bg-white shadow-lg p-5">
            <button
              onClick={() => setIsActive(false)}
              className="text-gray-600 text-2xl absolute top-5 right-5"
            >
              &times;
            </button>
            <Sidebar isActive={isActive} setIsActive={setIsActive} />
          </div>
        </div>
      )}
    </>
  );
};

export default Header;
