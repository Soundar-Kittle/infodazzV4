// const menu_data = [
//   // {
//   //   id: 1,
//   //   mega_menu: false,
//   //   has_dropdown: false,
//   //   title: "Home",
//   //   link: "/",
//   //   // sub_menus: [
//   //   //   { link: "/", title: "Main Home" },
//   //   //   { link: "/home-2", title: "It Solutions" },
//   //   //   { link: "/home-3", title: "Digital Agency" },
//   //   //   { link: "/home-4", title: "Home Saas" },
//   //   //   { link: "/home-5", title: "Photography" },
//   //   //   { link: "/home-6", title: "Minimal Portfolio" },
//   //   //   { link: "/home-7", title: "Law Firm" },
//   //   //   { link: "/home-8", title: "Creative Agency" },
//   //   //   { link: "/home-9", title: "Architecture" },
//   //   //   { link: "/home-10", title: "Seo Agency" },
//   //   // ],
//   // },
//   // {
//   //   id: 2,
//   //   mega_menu: false,
//   //   has_dropdown: false,
//   //   title: "About",
//   //   link: "/about",
//   // },
//   // {
//   //   id: 2,
//   //   mega_menu: false,
//   //   has_dropdown: false,
//   //   title: "Home",
//   //   link: "/",
//   // },
//   {
//     id: 3,
//     mega_menu: false,
//     has_dropdown: true,
//     title: "IT Solutions",
//     sub_menus: [
//       { link: "/web-development", title: "Web Development" },
//       { link: "/software-development", title: "Software Development" },
//       { link: "/app-development", title: "App Development" },
//     ],
//   },

//   {
//     id: 4,
//     mega_menu: false,
//     has_dropdown: true,
//     title: "Digital Marketing",
//     sub_menus: [
//       { link: "/sem-smm-seo", title: "SEO/SEM/SMM" },
//       { link: "/creative-design", title: "Creative Design" },
//       { link: "/brand-building", title: "Brand Building" },
//     ],
//   },
//   {
//     id: 5,
//     mega_menu: false,
//     has_dropdown: true,
//     title: "Event Management",
//     sub_menus: [
//       { link: "/corporate-events", title: "Corporate Events" },
//       { link: "/personal-events", title: "Personal Events " },
//       // { link: "/photography", title: "Photography" },
//       // { link: "/video-production", title: "Videography" },
//     ],
//   },
//   {
//     id: 6,
//     mega_menu: false,
//     has_dropdown: false,
//     title: "Photo & Videography",
//     link: "/photography",
//   },
//   // {
//   //   id: 7,
//   //   mega_menu: false,
//   //   has_dropdown: false,
//   //   title: "Portfolio",
//   //   link: "/portfolio",
//   // },
//   {
//     id: 7,
//     mega_menu: false,
//     has_dropdown: false,
//     title: "Contact Us",
//     link: "/contact-us",
//   },
// ];
// export default menu_data;

const   menu_data = [
    {
    id: 1,
    mega_menu: false,
    has_dropdown: true,
    title: "Services",
    sub_menus: [
      { link: "/digital-marketing", title: "Digital Marketing" }, 
      { link: "/it-solutions", title: "IT Soutions" },
      { link: "/animation-vfx", title: "Animation & VFX " },
      { link: "/event-management", title: "Event Management" },
      { link: "/photo-and-videography", title: "Photo/Videography " },       
           ],
  },

  {
    id: 2,
    mega_menu: false,
    has_dropdown: true,
    title: "Group",
    sub_menus: [
      { link: "https://kittle.ltd", title: "Kittle Private Limited",target:"_blank" }, 
      { link: "https://www.internationaljournalssrg.org/", title: "Seventh Sense Research Group ",target:"_blank" },
      { link: "https://dsjournals.com", title: "Dream Science Foundation",target:"_blank" },
      { link: "https://kittle.ltd/", title: "KASTER",target:"_blank" },
      { link: "/", title: "Infodazz"},       
           ],
  },
  {
    id: 5,
    mega_menu: false,
    has_dropdown: false,
    title: "Media",
    link: "/media",
  },
  {
    id: 7,
    mega_menu: false,
    has_dropdown: false,
    title: "Connect Us",
    link: "/connect-us",
  },
];
export default menu_data;


// const menu_data = [
//   {
//   id: 1,
//   mega_menu: false,
//   has_dropdown: false,
//   title: "IT Soultions",
//   link: "/businesses",
// },

// {
//   id: 5,
//   mega_menu: false,
//   has_dropdown: false,
//   title: "Event Management",
//   link: "/media",
// },
// {
//   id: 7,
//   mega_menu: false,
//   has_dropdown: false,
//   title: "Photo & Videography",
//   link: "/connect-us",
// },
// {
//   id: 7,
//   mega_menu: false,
//   has_dropdown: false,
//   title: "Connect Us",
//   link: "/connect-us",
// },
// ];
// export default menu_data;
