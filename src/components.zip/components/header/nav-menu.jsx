"use client";

import Link from "next/link";
import React, { useState, useEffect } from "react";
import { IoHomeOutline } from "react-icons/io5";
import { BsChevronDown } from "react-icons/bs";
import menu_data from "./menu-data";

const NavMenu = () => {
  const [activeMenu, setActiveMenu] = useState(null);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  const toggleSubMenu = (menu) => {
    setActiveMenu(activeMenu === menu ? null : menu);
  };

  if (!mounted) return null;

  return (
    <ul className="flex space-x-6 items-center">
      {/* Home */}
      <li>
        <Link href="/" aria-label="Home">
          <IoHomeOutline size={22} className="text-gray-800 hover:text-blue-500 transition" />
        </Link>
      </li>

      {menu_data.map((item, i) => (
        <li key={i} className="relative group">
          {/* Normal link (no dropdown) */}
          {!item.has_dropdown ? (
            <Link
              href={item.link || "/"}
              className="text-gray-900 font-semibold uppercase hover:text-blue-600 transition"
            >
              {item.title}
            </Link>
          ) : (
            <div
              className="flex items-center space-x-1 cursor-pointer"
              onClick={() => toggleSubMenu(item.title)}
            >
              <span className="text-gray-900 font-semibold uppercase hover:text-blue-600 transition">
                {item.title}
              </span>
              <span className="text-lg font-bold text-gray-900">
                <BsChevronDown />
              </span>
            </div>
          )}

          {/* Submenus */}
          {item.has_dropdown && item.sub_menus && (
            <ul
              className={`absolute left-0 mt-2 w-72 bg-white shadow-lg rounded-md p-2 transition-all duration-300 z-20 ${
                activeMenu === item.title
                  ? "opacity-100 visible scale-100"
                  : "opacity-0 invisible scale-95"
              }`}
            >
              {item.sub_menus.map((sub_item, sub_i) => (
                <li key={sub_i}>
                  {sub_item.target === "_blank" ? (
                    <a
                      href={sub_item.link}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="block px-4 py-3 text-gray-900 font-medium hover:bg-gray-100 transition"
                    >
                      {sub_item.title}
                    </a>
                  ) : (
                    <Link
                      href={sub_item.link}
                      className="block px-4 py-3 text-gray-900 font-medium hover:bg-gray-100 transition"
                    >
                      {sub_item.title}
                    </Link>
                  )}
                </li>
              ))}
            </ul>
          )}
        </li>
      ))}
    </ul>
  );
};

export default NavMenu;
