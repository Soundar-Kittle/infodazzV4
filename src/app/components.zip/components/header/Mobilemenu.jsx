"use client";

import React, { useState } from "react";
import Link from "next/link";
import { FiPlus } from "react-icons/fi";
import menu_data from "./menu-data";

const MobileMenus = ({ menuOpen }) => {
  const [navTitle, setNavTitle] = useState("");

  // Toggle Dropdown Menu
  const openMobileMenu = (menu) => {
    setNavTitle(navTitle === menu ? "" : menu);
  };

  return (
    <nav className="w-full">
      <ul className="space-y-3">
        {menu_data.map((menu, i) => (
          <React.Fragment key={i}>
            {/* Normal Menu Item */}
            {!menu.has_dropdown && (
              <li onClick={menuOpen} className="text-gray-900 font-bold">
                <Link href={menu.link || "/"} className="block py-2 px-4 hover:bg-gray-100 rounded">
                  {menu.title}
                </Link>
              </li>
            )}

            {/* Dropdown Menu */}
            {menu.has_dropdown && (
              <li className="relative">
                <div className="flex items-center justify-between px-4 py-2 bg-gray-100 rounded">
                  <Link href={menu.link || "/"} className="text-gray-900 font-bold">
                    {menu.title}
                  </Link>
                  <button
                    onClick={() => openMobileMenu(menu.title)}
                    className="text-lg font-bold text-gray-900 transition-transform duration-300"
                  >
                    <FiPlus className={`transform ${navTitle === menu.title ? "rotate-45" : ""}`} />
                  </button>
                </div>
                <ul
                  className={`mt-2 pl-6 space-y-2 overflow-hidden transition-all duration-300 ${
                    navTitle === menu.title ? "max-h-96 opacity-100" : "max-h-0 opacity-0"
                  }`}
                >
                  {menu.sub_menus?.map((sub, i) => (
                    <li key={i} onClick={menuOpen}>
                      <Link href={sub.link || "/"} className="block py-2 px-4 text-gray-700 hover:bg-gray-200 rounded">
                        {sub.title}
                      </Link>
                    </li>
                  ))}
                </ul>
              </li>
            )}
          </React.Fragment>
        ))}
      </ul>
    </nav>
  );
};

export default MobileMenus;
