"use client";
import "react-chatbot-kit/build/main.css";

export default function ChatbotStyleLoader() {
  return null;
}