import React from 'react'

export default function Subhero() {
  return (
    <div>
      
    </div>
  )
}
